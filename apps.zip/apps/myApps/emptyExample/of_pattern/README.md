This must be placed three levels down in your openFrameworks folder to compile:
./apps/myApps/of_pattern